<?php
/*
|--------------------------------------------------------------------------
| SEPM TEAM PROJECT
|--------------------------------------------------------------------------
| Author: Vashisth Bhushan
| Project Saccoma.cf
|
|
|
*/
  define( 'DB_HOST', 'localhost' );          // Set database host
  define( 'DB_USER', 'vashisth_sepmteam' );             // Set database user
  define( 'DB_PASS', 'Saccomarocks@1234' );             // Set database password
  define( 'DB_NAME', 'vashisth_activate_saccoma' );        // Set database name

?>
