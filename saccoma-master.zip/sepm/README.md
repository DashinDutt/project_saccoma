
### Made for SEPM Group Project 

### Installing this application is easy, just follow these steps:
****

1. Import/load saccoma.sql into your mysql database. This should set up the basic structure of the database system.

2. Modify the includes/config.php and change the variables to match your host, database, username and passwords.

3. Change all Folder permission inside uploads folder either add them to group call `www` if available or `777`.

4. Then loging by typing **username** and **password**:


   Administrator        | Special User           | Default User
   ---------------------| -----------------------| -------------------
   **Username** : admin | **Username** : special | **Username** : user
   **Password** : admin | **Password** : special | **Password** : user

6. Good luck!  

- - - -

## Team number 18

- - - -

Powered by Vashsith Bhushan